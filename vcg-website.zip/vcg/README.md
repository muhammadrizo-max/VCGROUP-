# VisionCoreGroup Website

Professional website for VisionCoreGroup team.

## Stack
- **Frontend**: Pure HTML + CSS + JS (no framework dependencies)
- **Storage**: localStorage (browser-side, no backend needed)
- **Hosting**: Vercel (static)

## Pages
| Page | File | Description |
|------|------|-------------|
| Home | `index.html` | Main landing page with featured projects, team, blog |
| Projects | `projects.html` | Full project catalog with filter + search |
| Bots | `bots.html` | Bot catalog with filter + search |
| Team | `team.html` | Team members with role filter |
| Blog | `blog.html` | News & updates with category filter |
| Contact | `contact.html` | Contact form + channels |
| Admin | `admin.html` | Full admin panel |

## Admin Panel
- URL: `/admin.html`
- Login: `admin` / `vcg2026` (change in admin.html line with `ADMIN_PASS`)
- Features:
  - Dashboard with traffic charts
  - CRUD for projects, team, blog
  - View & manage contact messages
  - Statistics

## Deploy to Vercel
1. Create GitHub repo
2. Push this folder
3. Go to vercel.com → New Project → Import repo
4. Deploy (no config needed)

## Customize
- Colors: edit `:root` in `static/css/main.css`
- Data: first visit auto-populates from defaults in `static/js/main.js`
- Admin password: `ADMIN_PASS` in `admin.html`
- Contact links: `contact.html` direct edit

## Tech Notes
- All data stored in `localStorage` — no backend, no database needed
- Admin changes persist per-browser (localStorage)
- For production with real persistence: replace `DB` class with API calls to a backend
